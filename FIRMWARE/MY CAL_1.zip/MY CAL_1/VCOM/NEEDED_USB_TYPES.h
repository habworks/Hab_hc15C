
#ifndef __NEEDED_USB_TYPES_H__
#define __NEEDED_USB_TYPES_H__

typedef unsigned int   BOOL;


#endif